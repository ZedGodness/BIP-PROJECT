/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kvk;

import java.util.Random;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class Battery {
    private double usageHours;
    private double maxWatt;
    private double backupTime;
    private double batteryVoltage;
    private double reservedFratur;
    private int currentPercentage ;

    // Constructor
    public Battery(double usageHours, double maxWatt, double backupTime, double batteryVoltage, double reservedFratur) {
        this.usageHours = usageHours;
        this.maxWatt = maxWatt;
        this.backupTime = backupTime;
        this.batteryVoltage = batteryVoltage;
        this.reservedFratur = reservedFratur;
        this.currentPercentage = getRandomValue();
    }

    // Getters and Setters
    public double getUsageHours() {
        return usageHours;
    }

    public void setUsageHours(double usageHours) {
        this.usageHours = usageHours;
    }

    public double getMaxWatt() {
        return maxWatt;
    }

    public void setMaxWatt(double maxWatt) {
        this.maxWatt = maxWatt;
    }

    public double getBackupTime() {
        return backupTime;
    }

    public void setBackupTime(double backupTime) {
        this.backupTime = backupTime;
    }

    public double getBatteryVoltage() {
        return batteryVoltage;
    }

    public void setBatteryVoltage(double batteryVoltage) {
        this.batteryVoltage = batteryVoltage;
    }

    public double getReservedFratur() {
        return reservedFratur;
    }

    public void setReservedFratur(double reservedFratur) {
        this.reservedFratur = reservedFratur;
    }
    public int getCurrentPercentage() {
        return currentPercentage;
    }

    public void setCurrentPercentage(int percentage) {
        this.currentPercentage = percentage;
    }
    

    // Optional: toString method for easy display
    @Override
    public String toString() {
        return "Battery{" +
                "usageHours=" + usageHours +
                ", maxWatt=" + maxWatt +
                ", backupTime=" + backupTime +
                ", batteryVoltage=" + batteryVoltage +
                ", reservedFratur=" + reservedFratur +
                '}';
    }
    
    public double BatteryKw (Battery battery) {
        return  (battery.maxWatt * battery.usageHours * battery.reservedFratur) + (battery.maxWatt * battery.backupTime);
    }
    
    public double [] voltageLife (Battery battery) {
        return new double [] {(battery.batteryVoltage) + ((12.0 / 100) * battery.batteryVoltage), battery.batteryVoltage - ((2.0 / 100) * battery.batteryVoltage)};
    }
    
    public String isSellable (Battery battery) {
        double percentage = (battery.maxWatt * battery.backupTime) / (battery.maxWatt * battery.usageHours * battery.reservedFratur) * 100;
        if (percentage > 30) return "you can sell because the percentage is: " + percentage;
        return "you cant sell because the percentage is: " + percentage;
    }
    
    public int getRandomValue () {
        Random r = new Random();
        int randomValue = r.nextInt(101);
        return randomValue;
    }
    
    public void dischargeBattery (Battery battery) {
        
    }
    public void chargeBattery (Battery battery) {
        
    }
    
}
