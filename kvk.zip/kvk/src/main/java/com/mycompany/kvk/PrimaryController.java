package com.mycompany.kvk;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;
import org.json.JSONObject;

public class PrimaryController {
    
    private double ISS, JSS, SOLAR4K, SOLAR90K, GRID, SOLAR;
    int batteryLevel;
    Connection conn = null;
    Battery b = new Battery(12.0, 20.0, 5.0, 24.0, 1.5);

    // Weather components
    @FXML private FlowPane WeatherForecast;
    @FXML private FlowPane RealTimeWeather;

    // Energy components
    @FXML private FlowPane ReakTimeEnergy;
    @FXML private FlowPane EnergyForecast;

    // Consumer components
    @FXML private FlowPane ConsumerKvK;
    @FXML private FlowPane Consumer308;

    // Solar components
    @FXML private FlowPane BiggerSolarPlant;
    @FXML private FlowPane SmallerSolarPlant;

    // Grid components
    @FXML private FlowPane Grid;
    @FXML private FlowPane BatteryPane;

    // Scenario components
    @FXML private FlowPane Scenario;
    @FXML private Slider Slider;

    @FXML
    public void Test() {
        clearAllPanes();

        // === Weather Fetching ===
        new Thread(() -> {
            try {
                JSONObject weatherData = WeatherService.getCurrentWeather(WeatherService.KLAIPEDA_CITY[0]);
                JSONObject location = weatherData.getJSONObject("location");
                JSONObject current = weatherData.getJSONObject("current");

                String cityName = location.getString("name");
                double temperature = current.getDouble("temp_c");
                String condition = current.getJSONObject("condition").getString("text");
                double windSpeed = current.getDouble("wind_kph");
                int humidity = current.getInt("humidity");
                double pressure = current.getDouble("pressure_mb");

                String weatherInfo = String.format(
                    "Weather in %s:\nTemperature: %.1f°C\nCondition: %s\nWind: %.1f km/h\nHumidity: %d%%\nPressure: %.1f mb",
                    cityName, temperature, condition, windSpeed, humidity, pressure
                );

                Platform.runLater(() -> RealTimeWeather.getChildren().add(new Text(weatherInfo)));

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> RealTimeWeather.getChildren().add(new Text("Failed to load weather data.")));
            }
        }).start();

        // === Electricity Price Fetching ===
        new Thread(() -> {
            try {
                JSONObject priceData = ElectricityPriceFetcher.getCurrentPrice();

                if (priceData != null) {
                    String priceInfo = String.format(
                        "Current Electricity Price:\nHour Start (LT): %s\nPrice: %.2f EUR/MWh",
                        priceData.getString("Hour Start (LT)"),
                        priceData.getDouble("Price (EUR/MWh)")
                    );

                    Platform.runLater(() -> ReakTimeEnergy.getChildren().add(new Text(priceInfo)));
                } else {
                    Platform.runLater(() -> ReakTimeEnergy.getChildren().add(new Text("No electricity price data found.")));
                }

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> ReakTimeEnergy.getChildren().add(new Text("Failed to load electricity price.")));
            }
        }).start();

        // === Scenario Matching ===
        new Thread(() -> {
            // Simulated values; replace with actual logic or user inputs later
            String weather = "Bad";
            String price = "Low";
            String load = "Low";

            ScenarioMatcher.Scenario match = ScenarioMatcher.findMatchingScenario(weather, price, load);

            Platform.runLater(() -> {
                if (match != null) {
                    String output = String.format(
                        "Selected Scenario #%d\nWeather: %s\nPrice: %s\nLoad: %s\nBattery State: %s\nReasoning: %s",
                        match.number, match.weather, match.price, match.load, match.batteryState, match.reasoning
                    );
                    Scenario.getChildren().add(new Text(output));
                } else {
                    Scenario.getChildren().add(new Text("No matching scenario found."));
                }
                fetchDataInBackground();
                refreshBattery();
            });
        }).start();
    }

    private void clearAllPanes() {
        Platform.runLater(() -> {
            WeatherForecast.getChildren().clear();
            RealTimeWeather.getChildren().clear();
            ReakTimeEnergy.getChildren().clear();
            EnergyForecast.getChildren().clear();
            ConsumerKvK.getChildren().clear();
            BiggerSolarPlant.getChildren().clear();
            SmallerSolarPlant.getChildren().clear();
            Grid.getChildren().clear();
            BatteryPane.getChildren().clear();
            Scenario.getChildren().clear();
        });
    }
    private void fetchDataInBackground() {
        //System.out.println("IN FETCHING 1");
        conn = DatabaseConnection.getConnection();
        new Thread(() -> {
            ArrayList<Double> data = fetchDataFromDatabase();
            

            // Update UI on the JavaFX application thread
            Platform.runLater(() -> {
//                Label l = new Label(Double.toString(batterykw) + " KW, " + Double.toString(voltageLife[0]) + " voltage life, " + Double.toString(voltageLife[1]) + " \nmin life, and the state of whether we can sell: \n" + canSell + "%");
                GRID = ISS + JSS;
                SOLAR = SOLAR4K + SOLAR90K;
                Grid.getChildren().add(new Text (String.format("Grid: : %.2f", GRID)));
                ConsumerKvK.getChildren().add(new Text (String.format("ISS: %.2f", data.get(0))));
                ConsumerKvK.getChildren().add(new Text (String.format(" JSS: %.2f", data.get(1))));
                SmallerSolarPlant.getChildren().add(new Text (String.format("Solar 4KW: %.2f", data.get(2))));
                BiggerSolarPlant.getChildren().add(new Text (String.format("Solar 90KW: %.2f", data.get(3))));
            });
        }).start();
        
    }
    private ArrayList <Double> fetchDataFromDatabase() {
        //System.out.println("IN FETCHING 2");
        ArrayList <Double> result = new ArrayList<Double>();
        
        try (
            Statement stmt1 = this.conn.createStatement();
            Statement stmt2 = this.conn.createStatement();
            Statement stmt3 = this.conn.createStatement();
            Statement stmt4 = this.conn.createStatement();
            ResultSet rs1 = stmt1.executeQuery("SELECT TOP 1 \"kW tot mean\" FROM dbo.\"vw_ISS-01_History_Mean\" ORDER BY \"TimestampUTC\" DESC");
            ResultSet rs3 = stmt2.executeQuery("SELECT TOP 1 \"Real Power\" FROM dbo.\"vw_Solar-4kW_Power_history\" ORDER BY \"TimestampUTC\" DESC");
            ResultSet rs4 = stmt3.executeQuery("SELECT TOP 1 \"Real Power\" FROM dbo.\"vw_Solar-90kW_Power_history\" ORDER BY \"TimestampUTC\" DESC");
            ResultSet rs2 = stmt4.executeQuery("SELECT TOP 1 \"kW tot mean\" FROM dbo.\"vw_JSS-308_History_Mean\" ORDER BY \"TimestampUTC\" DESC")){
            
            // Fetch data from each result set
            while (rs1.next()) {
                ISS = rs1.getDouble(1);
            }
            result.add(ISS);
            while (rs2.next()) {
                JSS = rs2.getDouble(1);  
            }
            result.add(JSS);
            while (rs3.next()) {
                SOLAR4K = rs3.getDouble(1);
            }
            result.add(SOLAR4K);

            while (rs4.next()) {
                SOLAR90K = rs4.getDouble(1);
            }
            result.add(SOLAR90K);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        DatabaseConnection.closeConnection(conn);
        return result;
    }
    public void refreshBattery () {
        batteryLevel = b.getCurrentPercentage();
        BatteryPane.getChildren().add(new Text (String.format("Parecentage: : %d", batteryLevel) + "%"));
    }
}
